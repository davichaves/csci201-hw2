package dchaves_CSCI201_Assignment2;

public class coordinates {
	public int x, y;
}
